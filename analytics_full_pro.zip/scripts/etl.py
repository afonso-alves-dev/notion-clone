
import csv, json

data = []
with open('../data/sample.csv') as f:
    reader = csv.DictReader(f)
    for row in reader:
        data.append({"value": float(row["value"])})

with open('../data/output.json','w') as f:
    json.dump(data,f)

print("ETL complete")
