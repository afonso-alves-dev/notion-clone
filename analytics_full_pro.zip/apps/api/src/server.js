
const fastify = require('fastify')({ logger: true });

let dataset = [];

fastify.post('/upload', async (req, reply) => {
  const body = req.body;
  dataset = body.data || [];
  return { message: "Data uploaded", size: dataset.length };
});

fastify.get('/stats', async () => {
  if (!dataset.length) return { error: "No data" };

  const values = dataset.map(d => Number(d.value));
  const sum = values.reduce((a,b)=>a+b,0);
  const avg = sum / values.length;

  return {
    total: sum,
    average: avg,
    count: values.length
  };
});

fastify.get('/data', async () => dataset);

const port = process.env.PORT || 5002;

fastify.listen({ port, host: '0.0.0.0' }, err => {
  if (err) throw err;
  console.log("API running");
});
