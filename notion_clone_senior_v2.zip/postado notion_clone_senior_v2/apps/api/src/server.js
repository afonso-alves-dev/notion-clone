
const fastify = require('fastify')({ logger: true });

fastify.get('/', async () => {
  return { status: 'API running' };
});

fastify.listen({ port: 5000 }, (err) => {
  if (err) throw err;
  console.log("API running on 5000");
});
